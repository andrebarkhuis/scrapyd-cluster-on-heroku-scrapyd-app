import scrapy
import json
import re
import datetime
from game.mongo_repository import MongoRepository
from game.items import ProductItem
from game.items import MenuItem
from dateutil.parser import parse
from decimal import *
import numpy as np
from furl import furl
import sys

class TakealotSpider(scrapy.Spider) :
    name="TakealotSpider"
    
    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        kwargs['mongo_uri'] = crawler.settings.get("MONGO_URI")
        kwargs['mongo_database'] = crawler.settings.get('MONGO_DATABASE')
        return super(TakealotSpider, cls).from_crawler(crawler, *args, **kwargs)

    def __init__(self,mongo_uri=None, mongo_database=None, *args, **kwargs):    
        super(TakealotSpider, self).__init__(*args, **kwargs)
        self.repository = MongoRepository(mongo_uri, mongo_database)
        self.storeItem = self.repository.get_store(self.name)
     
        if(self.storeItem) is None:
            raise Exception('No store settings found for ' + self.name)

        self.settingsUrl = self.storeItem['url']
     
    def start_requests(self):
        url = 'https://api.takealot.com/rest/v-1-9-1/cms/merchandised-departments?display_only=True&platform=desktop'
        yield scrapy.Request(url, callback = self.get_merchandised_departments, dont_filter=False)
 
    def get_merchandised_departments(self, response):

        departments = json.loads(response.body)
                
        for department in departments['merchandised_departments']:
            department_id = department['department_id']
            
            url =  f'https://api.takealot.com/rest/v-1-9-1/searches/products,facets,breadcrumbs?filter=Type:{department_id}&searchbox=true'
            yield scrapy.Request(url, callback = self.get_department_products, dont_filter=False)

    def get_department_products(self, response):

        msp = json.loads(response.body)
        nextPage = msp['sections']['products']['paging']['next_is_after']
        productResults = msp['sections']['products']['results']
        
        categories = []           
        tags = []
        relatedBrands = []
        
        breadcrumbResults = msp['sections']['breadcrumbs']['results']
        for breadcrumb in breadcrumbResults:
            categories.append(breadcrumb['breadcrumb']['display_value'])

        facetResults = msp['sections']['facets']
        for facetResult in facetResults['results']:
          
            facet = facetResult['facet']

            if(facet['type']=='discrete_facet'):
                discrete_facet = facet['discrete_facet']
                if(discrete_facet['display_name'] == 'Brand'):
                    for brandFacet in discrete_facet['entries']:
                        relatedBrands.append(brandFacet['display_value'])

            if(facet['type']=='tree_facet'):
                tree_facet = facet['tree_facet']
                if(tree_facet['display_name'] == 'Category'):
                    for categoryFacet in tree_facet['entries']:
                        tags.append(categoryFacet['display_value'])

        for result in productResults:
            
            try:
                product_view = result['product_views']
                core = product_view['core']
                buybox_summary = product_view['buybox_summary']
                
                if(not self.is_valid_product(product_view)):
                    break

                price = Decimal(buybox_summary['prices'][0])
                isPromotion= buybox_summary['saving'] is not None
                product_images = []

                for image in product_view['gallery']['images']:
                    product_images.append(image.format(size='zoom'))

                if isPromotion:
                    pricePrevious = Decimal(buybox_summary['listing_price'])
                else:
                    pricePrevious = 0    

                productItem = ProductItem(
                name = core['title'],
                productCode  = core['id'],
                price = price,
                brand =   core['brand'],
                category = categories[-1],
                tags = list(set(tags)),
                sku = buybox_summary['tsin'],
                priceValidTo = datetime.datetime.now(),
                pricePrevious = pricePrevious,
                priceDiscount = (price - pricePrevious),
                isPromotion= buybox_summary['saving'] is None,
                image_url = product_images,
                image_processed = False,
                store = self.storeItem,
                source_url = str(response.url),
                rating = core['star_rating'],
                numberOfReviews = core['reviews'],
                timestamp = datetime.datetime.now(),
                availableOnline = buybox_summary['is_add_to_cart_available'] == 'true',
                relatedBrands = list(set(relatedBrands)))

                yield productItem
            except:
                print("Unexpected error:", sys.exc_info())
                continue
        
        if not nextPage is None:
            nextUrl = furl(response.url)
            nextUrl.remove(['after'])
            nextUrl.add({'after': str(nextPage)})
            yield scrapy.Request(url= nextUrl.url,  callback=self.get_department_products)

    def is_valid_product(self, product_view):
        core = product_view['core']
        buybox_summary = product_view['buybox_summary']

        if(core['brand'] is None):
            return False

        if(buybox_summary['prices'] is None):
            return False

        if(len(buybox_summary['prices']) > 1):
            return False                

        return True