import scrapy
import json
import re
import datetime
from game.mongo_repository import MongoRepository
from game.items import ProductItem
from game.items import MenuItem
from dateutil.parser import parse
from decimal import Decimal, getcontext
import numpy as np
import html

class PicknPaySpider(scrapy.Spider) :
    name="PicknPaySpider"

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        kwargs['mongo_uri'] = crawler.settings.get("MONGO_URI")
        kwargs['mongo_database'] = crawler.settings.get('MONGO_DATABASE')
        return super(PicknPaySpider, cls).from_crawler(crawler, *args, **kwargs)

    def __init__(self,mongo_uri=None, mongo_database=None, *args, **kwargs):    
        super(PicknPaySpider, self).__init__(*args, **kwargs)
        self.repository = MongoRepository(mongo_uri, mongo_database)
        self.storeItem = self.repository.get_store(self.name)
     
        if(self.storeItem) is None:
            raise Exception('No store settings found for {0}'.format(self.name))

        self.settingsUrl = self.storeItem['url']
   
    def start_requests(self):

        if(self.storeItem) is None:
            raise Exception('No settings found for {0}'.format(self.name)) 
        
        #  Start from root url. Attempt to extract all menu urls.
        yield scrapy.Request(self.settingsUrl, callback = self.parse_menuItems, dont_filter=False)

    def parse_menuItems(self, response):
        #try only select the menu

        hrefs = response.css("div.sub-navigation li.yCmsComponent a")

        for link in hrefs:
            a = link.css("a").attrib["href"]
            title = link.css("a").attrib["title"]
            metaData = { "category": title}

            if(a) is not None:
                item  = MenuItem(
                    name = title,
                    url = response.urljoin(a)
                )
                #only let the Pipeline handle Product
                yield scrapy.Request(item['url'], callback = self.parse_page, meta=metaData)

    def parse_page(self, response):
        # getcontext().prec = 8   
        tags = response.css("ul.facet-list-hidden span.facet-text a::text").getall()
        category = response.meta["category"]

        relatedBrands = []
        releventBrandsTag = response.css("form input[value^='']::attr(value)").getall()        

        for r in releventBrandsTag:
            x = str(r.split(':')[3])
            relatedBrands.append(html.unescape(x).replace("+"," "))

        for containerDiv in response.css("div.productCarouselItemContainer"):

            imageUrl = containerDiv.css("div.thumb img").attrib["src"]
            
            try:
                productCodeSource = str(imageUrl).split("/")[-1]
                productCode= productCodeSource.split("-")[1]
            except IndexError: 
                productCode =""

            productDiv = containerDiv.css("div.item.js-product-card-item.product-card-grid")
            productName = productDiv.css("div.item-name::text").get()
            productPrice = Decimal(productDiv.css('div.currentPrice::text').get().strip().replace("R","").replace(",",""))
            productOldPrice = productDiv.css("div.oldPrice::text").get()
            validUntil = datetime.datetime.now()
            brand = productName.split(" ")[0]
            
            # Add substitute for No Name Brand
            if(brand is "No"):
                brand ="No Name"

            if(productOldPrice) is not None:
                isPromotion=True
                pricePrevious = Decimal(str(productOldPrice).strip().replace("R","").replace(",",""))
                priceDiscount = Decimal(pricePrevious) - productPrice
            else:
                isPromotion = False
                pricePrevious = Decimal(0)
                priceDiscount = Decimal(0)

            item = ProductItem(
            name = str(productName),
            productCode  = productCode,
            price = productPrice,
            brand = brand,
            relatedBrands = list(set(relatedBrands)),
            category = category,
            tags = list(set(tags)),
            priceValidTo = validUntil,
            priceDiscount = priceDiscount,
            pricePrevious = pricePrevious,
            isPromotion= isPromotion,
            image_url = eval("['"+ imageUrl + "']"),
            image_processed = False,
            source_url = str(response.url),
            store = self.storeItem,
            timestamp = datetime.datetime.now())

            yield item

        next_page = response.css("li.pagination-next a::attr(href)").get()
        if not next_page is None:
            next_page = response.urljoin(next_page[0])
            yield scrapy.Request(next_page, callback=self.parse_page)