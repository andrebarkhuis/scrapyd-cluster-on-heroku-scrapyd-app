import scrapy
import json
import re
import datetime
from game.mongo_repository import MongoRepository
from game.items import ProductItem
from game.items import MenuItem
from dateutil.parser import parse
from decimal import *
import numpy as np

class GameSpider(scrapy.Spider) :
    name="GameSpider"
    
    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        kwargs['mongo_uri'] = crawler.settings.get("MONGO_URI")
        kwargs['mongo_database'] = crawler.settings.get('MONGO_DATABASE')
        return super(GameSpider, cls).from_crawler(crawler, *args, **kwargs)

    def __init__(self,mongo_uri=None, mongo_database=None, *args, **kwargs):    
        super(GameSpider, self).__init__(*args, **kwargs)
        self.repository = MongoRepository(mongo_uri, mongo_database)
        self.storeItem = self.repository.get_store(self.name)
     
        if(self.storeItem) is None:
            raise Exception('No store settings found for {0}'.format(self.name))

        self.settingsUrl = self.storeItem['url']
        self.imageBaseUrl = self.storeItem['imageBaseUrl']
     
    def start_requests(self):
        #  Start from root url. Attempt to extract all menu urls.
          yield scrapy.Request(self.settingsUrl, callback = self.parse_menuItems, dont_filter=False)
 
    def parse_menuItems(self, response):
        #try only select the menu
        menu = response.css("ul.nav__links.nav__links--products.js-offcanvas-links")
        hrefs = menu.css("ul.sub-navigation-list.has-title li.yCmsComponent.nav__link--secondary a")
        
        for link in hrefs:
            a = link.css("a").attrib["href"]

            if(a) is not None:
                item  = MenuItem(     
                    name = link.css("a").attrib["title"],
                    url = response.urljoin(a)
                )
                #only let the Pipeline handle Product 
                yield scrapy.Request(item['url'], callback = self.parse_page)

    def parse_page(self, response):
        
        tags = self.get_tags(response)
     
        for product in response.css("div.product-item.productListerGridDiv"):
            
            productData = json.loads(product.css('input.js-gtmProductList::attr(value)').get())
            productPrice = Decimal(productData['price'])
            isPromotion = False
            validUntil = datetime.datetime.now()
            
            priceValidUntilElement =  product.css('span.valid-until-text::text')
            if not priceValidUntilElement is None:
                try:
                    validUntil = parse(str(priceValidUntilElement.extract()), fuzzy_with_tokens=True)[0]
                    isPromotion = True
                except ValueError:
                    validUntil = datetime.datetime.now()
                    isPromotion = False
            
            pricePrevious = self.get_previous_price(product, productPrice)

            priceDiscount = pricePrevious - productPrice

            item = ProductItem(
            name = str(productData['name']),
            productCode  = str(productData['id']),
            price = productPrice,
            brand =   str(productData['brand']),
            category = str(productData['category']),
            tags = tags,
            priceValidTo = validUntil,
            priceDiscount = priceDiscount,
            pricePrevious = pricePrevious,
            isPromotion= isPromotion,
            image_url = eval( "['"+ self.storeItem['imageBaseUrl'] + product.css("a div.productPrimaryImage img::attr(src)").extract()[0] + "']"),
            image_processed = False,
            store = self.storeItem,
            source_url = str(response.url),
            timestamp = datetime.datetime.now())
            
            yield item

        next_page = response.css("li.pagination-next a::attr(href)").get()
        if not next_page is None:
            next_page = response.urljoin(next_page[0])
            yield scrapy.Request(next_page, callback=self.parse_page)
    
    def get_tags (self, response):
        x = str(response.css("head title::text").get())
        tags = " ".join(x.split()).split("|")
        return tags

    def get_previous_price(self, product, currentPrice):
        previousPriceElement = product.css("div.details > div.price > span.price.strikethrough-text-plp > span.strikethrough::text")
        if not previousPriceElement is None:
            try:
                NUMERIC_CONST_PATTERN = "[-+]? (?: (?: \d* \. \d+ ) | (?: \d+ \.? ) )(?: [Ee] [+-]? \d+ ) ?"
                rx = re.compile(NUMERIC_CONST_PATTERN, re.VERBOSE)
                return Decimal(rx.findall(str(previousPriceElement.get()).replace(",",""))[0])
            except Exception:
                return Decimal(currentPrice)