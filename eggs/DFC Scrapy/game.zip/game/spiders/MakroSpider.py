import scrapy
import json
import re
import datetime
from game.mongo_repository import MongoRepository
from game.items import ProductItem
from game.items import MenuItem
from dateutil.parser import parse
from decimal import *
import numpy as np
import html

class MakroSpider(scrapy.Spider) :
    name="MakroSpider"
 
    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        kwargs['mongo_uri'] = crawler.settings.get("MONGO_URI")
        kwargs['mongo_database'] = crawler.settings.get('MONGO_DATABASE')
        return super(MakroSpider, cls).from_crawler(crawler, *args, **kwargs)

    def __init__(self,mongo_uri=None, mongo_database=None, *args, **kwargs):    
        super(MakroSpider, self).__init__(*args, **kwargs)
        self.repository = MongoRepository(mongo_uri, mongo_database)
        self.storeItem = self.repository.get_store(self.name)
        
        if(self.storeItem) is None:
            raise Exception('No store settings found for {0}'.format(self.name))

        self.settingsUrl = self.storeItem['url']
     
    def start_requests(self):
          yield scrapy.Request(self.settingsUrl, callback = self.extract_regions, dont_filter=True)
 
    def extract_regions(self, response):

        regions = response.xpath("//a[@data-region-code]")
        for regionElement in regions:
            regionCode = regionElement.attrib['data-region-code']
            request_region = scrapy.FormRequest(self.settingsUrl, callback=self.request_change_region, dont_filter=True)
            request_region.meta["region-code"] = regionCode
            request_region.meta["region-name"] = regionElement.xpath("./text()").get().strip()
            yield request_region

    #Set the region before crawling starts
    def request_change_region(self, response):

        regionCode = response.meta['region-code']
        CSRFToken = response.xpath("//input[@name='CSRFToken']/@value").get()

        httpRequest = scrapy.FormRequest(url="https://www.makro.co.za/_s/my-region", method="POST", 
            headers=response.request.headers, 
            formdata={'regionIsoCode' : str(regionCode),'CSRFToken': str(CSRFToken) }, 
            callback=self.begin_region_crawl, 
            meta=response.meta, dont_filter=True)

        yield httpRequest

    #Navigate to main root page
    def begin_region_crawl(self, response):
        yield scrapy.Request(url='https://www.makro.co.za', meta=response.meta, method='GET',
        callback=self.parse_menuItems, dont_filter=True)

    # Crawl through the menu to get department pages.
    def parse_menuItems(self, response):
        for link in response.css("ul.sub-navigation-list-three li.yCmsComponent.nav__link.js_nav__link"):
            a = link.css("a").attrib["href"]

            if(a) is not None:
                item  = MenuItem(     
                    name = link.css("a").attrib["title"],
                    url = response.urljoin(a)
                )
                #only let the Pipeline handle Product 
                yield scrapy.Request(url=item['url'], callback = self.parse_page, meta= response.meta, dont_filter=True)

    # Crawl through department page for all products, page next when applicable
    def parse_page(self, response):
    
        regionCode = response.meta['region-code']
        regionName = response.meta['region-name']
        tags = self.get_tags(response)
        relatedBrands = self.get_relatedBrands(response)

        for productElement in response.css("div.mak-product-tiles-container__product-tile"):
            
            productJson = productElement.css('input.js-gtmProductListItem::attr(value)').get()
            productData = json.loads(productJson)
            productPrice = Decimal(productData['price'])
            isPromotion = self.is_productPromotion(productElement)
            priceDiscount = self.get_priceDiscount(productElement)
            pricePrevious =  productPrice + priceDiscount
            
            productItem = ProductItem(
            name = str(productData['name']),
            productCode  = str(productData['id']),
            price = productPrice,
            brand =  str(productData['brand']).title(),
            category = self.get_category(response),
            tags = list(set(tags)),
            priceValidTo = datetime.datetime.now(),
            priceDiscount = priceDiscount,
            pricePrevious = pricePrevious,
            isPromotion= isPromotion,
            image_url = [productElement.css("a.product-tile-inner__img img::attr(data-src)").get()],
            image_processed = False,
            store = self.storeItem,
            source_url = str(response.url),
            regionName = regionName,
            regionCode = regionCode,
            timestamp = datetime.datetime.now(),
            relatedBrands = list(set(relatedBrands)))

            productItem["rating"] = self.get_productRating(productElement)
            productItem['availableOnline'] = self.is_avilableOnline(productElement)

            if(self.has_no_stock(productElement)):
                productItem['regionStock'] = 0
            
            formData = self.build_form(productElement)
            if(formData is not None):
                yield scrapy.FormRequest(url="https://www.makro.co.za/cart/add", method="POST", headers=response.request.headers, 
                formdata=formData, callback=self.productStock_response, dont_filter=True, meta={'productItem': productItem})
            else:                
                yield productItem   

        next_page = response.css("li.pagination-next a::attr(href)").get()
        if not next_page is None:
            next_page = response.urljoin(next_page[0])
            yield scrapy.Request(next_page, callback=self.parse_page, meta=response.meta, dont_filter=True)
 
    def productStock_response(self, response):
        try:
            productItem = response.meta['productItem'] 
            data = json.loads(response.body)
            selector = scrapy.Selector(text=data['addToCartLayer'], type='html')

            if(selector is not None):
                availableStock=  selector.xpath("//input[@name='quantityAllowed']/@value")
                if(availableStock is not None):
                    productItem['regionStock'] = int(availableStock.get().strip())
            yield productItem
        except:
            yield productItem

    def build_form(self, productElement):
        formElement = productElement.css("form.add_to_cart_form")
        if formElement is not None:
            return {
            'productCodePost' : str(formElement.css("input[name^='productCodePost']::attr(value)").get()), 
            'productNamePost' : str(formElement.css("input[name^='productNamePost']::attr(value)").get()), 
            'productPostPrice': str(formElement.css("input[name^='productPostPrice']::attr(value)").get()), 
            'CSRFToken': str(formElement.css("input[name^='CSRFToken']::attr(value)").get()),
            'pageType': 'grid',
            'qty': '1000',
            'xhr': '1'}

        return None

    def get_tags (self, response):
        x = str(response.css("body title::text").get())
        tags = " ".join(x.split()).split("|")
        return tags

    def get_category (self, response):
        return response.css("ol.breadcrumb li.active::text").get()

    def get_priceDiscount(self, productElement):
        defaultValue = Decimal(0)
        savingElement = productElement.css("div.saving::text")
        if savingElement is not None:
            try:
                NUMERIC_CONST_PATTERN = "[-+]? (?: (?: \d* \. \d+ ) | (?: \d+ \.? ) )(?: [Ee] [+-]? \d+ ) ?"
                rx = re.compile(NUMERIC_CONST_PATTERN, re.VERBOSE)
                return Decimal(rx.findall(str(savingElement.get()).replace(",",""))[0])
            except Exception:
                return defaultValue
        return defaultValue

    def is_productPromotion(self, productElement):
        if productElement.css('span.ONPROMOTION') is None:
            return False
        else:
            return True

    def is_avilableOnline(self, productElement):
        shopableElement = productElement.xpath("//input[@name='shopable']/@value")
        if(shopableElement is not None):
            return shopableElement.get()
        else:
            return ""
    
    def has_no_stock(self, productElement):
        noStockElement = productElement.css("form.add_to_cart_form").css("div.no-stock")
        if(noStockElement is not None):
            return True
        else:
            return False

    def get_relatedBrands(self, response):
        relatedBrands = []
        brandFacetElement = response.css('#mak-collapse-brand')
        if(brandFacetElement is not None):
            brandsElement = brandFacetElement.css('form span.facet__list__text::text').getall()
            for brand in brandsElement:
                relatedBrands.append(brand.strip())
        
        return relatedBrands

    def get_productRating(self, productElement):

        ratingElement = productElement.css("div.rating-stars")
        if(ratingElement is not None):
            dataRatingAttr = ratingElement.xpath("./@data-rating").extract_first()
            return json.loads(dataRatingAttr)["rating"]
        else:
            return ""