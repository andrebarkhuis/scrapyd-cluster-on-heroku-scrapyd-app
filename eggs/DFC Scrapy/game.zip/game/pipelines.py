# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import pymongo
import datetime
from game.mongo_repository import MongoRepository
from game.items import JobItem, MenuItem, ProductItem

class MongoPipeline:
    
    def __init__(self, mongo_uri, mongo_db):
        self.mongo_uri = mongo_uri
        self.mongo_db = mongo_db
        self.repository = MongoRepository(mongo_uri, mongo_db)

    @classmethod
    def from_crawler(cls, crawler):

        return cls(
            mongo_uri=crawler.settings.get('MONGO_URI'),
            mongo_db=crawler.settings.get('MONGO_DATABASE')
        )

    def open_spider(self, spider):
           self.jobItem = self.repository.create_Job(spider.name)

    def close_spider(self, spider):

        self.jobItem['completed'] = datetime.datetime.now().isoformat()
        self.jobItem['status'] = "success"

        self.jobItem['first_log_time'] = spider.stats.get_value("scraped_items")
        self.jobItem['duration'] = datetime.time.fromisoformat(spider.stats.get_value("runtime"))
        self.jobItem['crawled_pages'] = int(spider.stats.get_value("crawled_pages"))
        self.jobItem['scraped_items'] = int(spider.stats.get_value("scraped_items"))
        self.jobItem['shutdown_reason'] = spider.stats.get_value("shutdown_reason")
        self.jobItem['finish_reason'] = spider.stats.get_value("finish_reason")
        self.jobItem['log_critical_count'] = int(spider.stats.get_value("log_critical_count"))
        self.jobItem['log_error_count'] = int(spider.stats.get_value("log_error_count"))
        self.jobItem['log_warning_count'] = int(spider.stats.get_value("log_warning_count"))
        self.jobItem['log_redirect_count'] = int(spider.stats.get_value("log_redirect_count"))
        self.jobItem['log_retry_count'] = int(spider.stats.get_value("log_retry_count"))
        self.jobItem['log_ignore_count'] = int(spider.stats.get_value("log_ignore_count"))

        self.repository.save_job(self.jobItem)

    def process_item(self, item, spider):
        if isinstance(item, ProductItem):
            productItem = self.proces_product(item, spider) 
            return productItem
        raise Exception("item not configured for spider {0}".format(spider.name))

    def proces_product(self, item, spider):
        item["jobId"] = str(self.jobItem['_id'])
        self.repository.save_product(item)
        return item