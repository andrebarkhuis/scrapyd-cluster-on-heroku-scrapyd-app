import pymongo
import datetime
from game.items import JobItem, MenuItem, ProductItem
from bson.codec_options import TypeRegistry
from bson.decimal128 import Decimal128
from bson.codec_options import TypeCodec
from decimal import *
from bson.codec_options import CodecOptions

class MongoRepository(object):

    Job_Collection="job"
    Product_Collection="product"
    Setting_Collection="store"

    def __init__(self, uri, database):
        self.mongo_uri = uri
        self.mongo_db = database 

    def get_store(self, name):
        return self.get_collection(self.Setting_Collection).find_one({"spiderName": name})

    def save_job(self, jobItem):
        self.get_collection(self.Job_Collection).update_one(
            {"_id": jobItem["_id"]},
            {"$set": dict(jobItem)}
         )
        
    def create_Job(self, jobName):
        jobItem = JobItem()
        jobItem['name'] = jobName
        jobItem['started'] = datetime.datetime.now().isoformat()
        jobItem['status'] = "inprogress"
        jobItem['_id'] = self.get_collection(self.Job_Collection).insert_one(dict(jobItem)).inserted_id
        return jobItem

    def save_product(self, productItem):
       self.get_collection(self.Product_Collection).insert_one(dict(productItem))
       return productItem

    def get_collection(self, name):
        codec_options = CodecOptions(type_registry = TypeRegistry(fallback_encoder = self.fallback_encoder))      
        self.client = pymongo.MongoClient(self.mongo_uri)
        return self.client.get_database(self.mongo_db).get_collection(name, codec_options = codec_options)

    def close_connection(self):
        self.client.close()

    def fallback_encoder(self, value):
        if isinstance(value, Decimal):
            return Decimal128(value)

        return value   

     