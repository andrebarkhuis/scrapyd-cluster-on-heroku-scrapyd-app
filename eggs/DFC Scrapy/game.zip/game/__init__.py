import os
import json
import pkgutil
import logging

path = "{}/dfc-gcp-key.json".format(os.getcwd())

credentials_content = {
  "type": "service_account",
  "project_id": "dfc-storeaudit",
  "private_key_id": "ee5fcb00040c471a7258db6e5f9bfd0bd41ebe4e",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDfDJjrqZAqLXT/\nW/nqxMjbnWBdZyCI5O/eS3RD+JQQb1ZP8iFEIrOE22Y/p8aENs+fhpKyzDG9lbbZ\n6OOhBezz19fY53FhA8jqc6HG+TPfYbTd8sICEoizingBDdKjpC2AD2nJiMHRwe8b\nusXKLlSMjQYHmWpbYQBz5p4UlDcOf4dgciSEpzGRaxz/7ueT2TstGeGMwCPh3xJU\na9cyhqIwYTUM0Z5bnEoybaDUQObstNgxRYaVh3r3iJ+8/9nj0o13xi2aAQ/2UGJx\nfxXyCs2jPT9pUSRsVUmRBI0gqym6KvvsiI38w8eV/67ZBzmCx9zKpIpPZBCLvvff\npTCEWqwtAgMBAAECggEAByseOgqxy6040qEn28v1wZsh9vaCxOuIqv4FT07soUeW\nwEyBlbFA0D8F3vtbJbImQ5P9YHowCg4G+aNit3Dbj+2qrfmoOuw2d5R+SUkGigIX\noD92TT8/vfdwCmahk6lJ3hEAvx2iTwW608sRosEQ7hB1NmbPlH6+Vzs87t/hkhln\nQd0jMucETL6J9lRXdAWEgeURgshHJpXO6aK32tI8HNbaGz8g3X3shWH540yhthD4\nqeNtD49yCBNJYmzTnXXrZKJHEeM+QT1V8LsMgeLN2l5lLGDprv3rFckQY5YseuH2\nysjZjT5/vC7wJuHqm0mqdxPpsoNFhCKsOki444RycQKBgQD+72SrYAXcpPKwD4HL\nQe55IL1Fc5qgtoqJXNjz2NMt70yuHFT7XocZwmVfDdDTfUw3T7BabV0cg/PxVJXL\nJxmDmsnfJoqBolFU9edFYW9jDX0OhL/tZfuvsKrF3oRkT0CagMUoccysS2BKeuRy\nN6zS81CYrIN/ARMMA9JVEr6KkQKBgQDf+xugF8A1oAJSRsanSmpQWv2qbZV2LkhZ\nwSMR1ffE8yUf1BvA19r/uO2TY2C61i54+Ko8ajkvn9/7aPdJIlQdZRAITPTpuwX9\nN+UWTuAPIhpPXergMaMn2CDgASYQbucjbyYzXVHXS+C2CTrQoJvAjSvNHyDce/jn\ns3o7OJC93QKBgBw/rqoGw9+FL5cuwLUjIyes5wwxGStBzuwVq7yphA0M/TQ103zf\nJp1GGzGDOGaW9cETRXlfsPed74QIWWjfdkZM+p2Nib9/mv+NGAlqGIujTP4024eU\ny2TWcLXoSEdNON1l83Ld2U4mNA9Mus+lN7NQXtfsFc4W8mNccQwYPaDhAoGBALV8\nc7r5473P5HGkdazyCEkKIYap+rRi9i775x25oWUNm2Q56y8L+KDCyIZnvOZHTCqr\nWs1PSP0E72l4eP7ieQPEcwQ2zzBgYY73boHv8W9xs53hvMJilhBf+OtpIt2n71Pv\n6SUvlXP9QJxfyC9qJCoWeYpgkbD2Jw4fiIhZ4jZlAoGBAL3mUG/F3lI0fkWLHxlr\nlnYoh0BpBXCu06EHeAdYIOebCLen5713V/Arex5C/o5hJA9ESMO+awNIQDRGcilo\ntoz6rAHm/q6QkX7UiAtT62Hdb/sdb6mZ4Matd93aqzK3KJnDF0Pjwq5ks3+R1uLe\nwFfhSNyEG8IhwtHkEXW2/iJK\n-----END PRIVATE KEY-----\n",
  "client_email": "dfc-scrapy-images@dfc-storeaudit.iam.gserviceaccount.com",
  "client_id": "101985289221935525278",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/dfc-scrapy-images%40dfc-storeaudit.iam.gserviceaccount.com"
}

with open(path, "w") as text_file:
    text_file.write(json.dumps(credentials_content))

logging.warning("Path to credentials: %s" % path)
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = path

