# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

class MenuItem(scrapy.Item):
    _id = scrapy.Field()
    url = scrapy.Field()
    name = scrapy.Field()
    isCompleted = scrapy.Field()

class ProductItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    productCode =scrapy.Field()
    name = scrapy.Field()
    price = scrapy.Field()
    brand = scrapy.Field()
    relatedBrands = scrapy.Field()
    category = scrapy.Field()
    priceValidTo = scrapy.Field()
    pricePrevious = scrapy.Field()
    priceDiscount = scrapy.Field()
    isPromotion = scrapy.Field()
    image_url = scrapy.Field()
    image_processed = scrapy.Field()
    source_url = scrapy.Field()
    timestamp = scrapy.Field()
    store = scrapy.Field()
    jobId = scrapy.Field()
    tags = scrapy.Field()
    sku = scrapy.Field()
    nationalStock = scrapy.Field()
    regionStock = scrapy.Field()
    regionCode = scrapy.Field()
    regionName = scrapy.Field()
    availableOnline = scrapy.Field()
    rating = scrapy.Field()
    numberOfReviews = scrapy.Field()

class JobItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    name = scrapy.Field()
    started = scrapy.Field()
    completed = scrapy.Field()
    status=scrapy.Field()
    first_log_time=scrapy.Field()
    duration=scrapy.Field()
    crawled_pages=scrapy.Field()
    scraped_items=scrapy.Field()
    shutdown_reason=scrapy.Field()
    finish_reason=scrapy.Field()
    log_critical_count=scrapy.Field()
    log_error_count=scrapy.Field()
    log_warning_count=scrapy.Field()
    log_redirect_count=scrapy.Field()
    log_retry_count=scrapy.Field()
    log_ignore_count=scrapy.Field()

# class SettingsItem(scrapy.Item):
#     # define the fields for your item here like:
#     _id = scrapy.Field()
#     storeId = scrapy.Field()
#     name = scrapy.Field()
#     url = scrapy.Field()
#     imageBaseUrl = scrapy.Field()
